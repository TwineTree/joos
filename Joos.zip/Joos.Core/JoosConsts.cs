﻿namespace Joos
{
    public class JoosConsts
    {
        public const string LocalizationSourceName = "Joos";
    }
}